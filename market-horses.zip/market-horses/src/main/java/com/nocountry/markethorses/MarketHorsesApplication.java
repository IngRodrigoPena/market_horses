package com.nocountry.markethorses;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MarketHorsesApplication {

	public static void main(String[] args) {
		SpringApplication.run(MarketHorsesApplication.class, args);
	}

}
